# Frontend Assessment

##### How to run:
- Install Yarn serve
    - `yarn global add serve`
- Run the build folder using the command `serve -s build`